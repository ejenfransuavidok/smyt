from django.test import TestCase
from models import Rooms, Users
from datetime import datetime

# Create your tests here.

class SaveObjectsTestCase(TestCase):
    def test_add_to_users(self):
        u = Users()
        u.name = 'name'
        u.paycheck = 1000
        u.date_joined = datetime.strptime('12/25/2014', '%m/%d/%Y')
        u.save()
        self.assertEqual(Users.objects.count(), 1)
    def test_add_to_rooms(self):
        r = Rooms()
        r.department = 'department'
        r.spots = 1000
        r.save()
        self.assertEqual(Rooms.objects.count(), 1)
    def test_change_users(self):
        u = Users()
        u.name = 'name'
        u.paycheck = 1000
        u.date_joined = datetime.strptime('12/25/2014', '%m/%d/%Y')
        u.save()
        self.assertEqual(Users.objects.count(), 1)
        u.date_joined = datetime.strptime('12/01/2014', '%m/%d/%Y')
        u.save()
    def test_change_rooms(self):
        r = Rooms()
        r.department = 'department'
        r.spots = 1000
        r.save()
        self.assertEqual(Rooms.objects.count(), 1)
        r.spots = 1
        r.save()
