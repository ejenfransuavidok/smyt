# -*- coding: utf-8 -*-
from django.db import models

# Create your models here.

class Users(models.Model):
    name = models.CharField(max_length=255)
    paycheck = models.IntegerField()
    date_joined = models.DateField()
    def __unicode__(self):
        return u'name-%s, paycheck=%s, date_joined=%s' % (self.name, self.paycheck, self.date_joined)

class Rooms(models.Model):
    department = models.CharField(max_length=255)
    spots = models.IntegerField()
    def __unicode__(self):
        return u'department-%s, spots-%s' % (self.department, self.spots)
