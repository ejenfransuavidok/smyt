# Django
from django.contrib import admin

# Internal
from .models import Users, Rooms


class UsersAdmin(admin.ModelAdmin):
    fields = ('name', 'paycheck', 'date_joined',)
    list_display = ('id', 'name', 'paycheck', 'date_joined',)

class RoomsAdmin(admin.ModelAdmin):
    fields = ('department', 'spots',)
    list_display = ('id', 'department', 'spots',)

admin.site.register(Users, UsersAdmin)
admin.site.register(Rooms, RoomsAdmin)
