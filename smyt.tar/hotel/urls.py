from django.conf.urls import patterns, include, url

urlpatterns = patterns('',
    url(r'^users/$', 'hotel.views.users', name='users'),
    url(r'^adduser/$', 'hotel.views.adduser', name='adduser'),
    url(r'^changeuser/$', 'hotel.views.changeuser', name='changeuser'),
    url(r'^rooms/$', 'hotel.views.rooms', name='rooms'),
    url(r'^addroom/$', 'hotel.views.addroom', name='addroom'),
    url(r'^changeroom/$', 'hotel.views.changeroom', name='changeroom'),
)
