from django import forms
from models import Rooms, Users

class UsersForm(forms.ModelForm):
    name = forms.CharField(max_length=255)
    paycheck = forms.IntegerField()
    date_joined = forms.DateField()

    # An inline class to provide additional information on the form.
    class Meta:
        # Provide an association between the ModelForm and a model
        model = Users

class RoomsForm(forms.ModelForm):
    department = forms.CharField(max_length=255)
    spots = forms.IntegerField()

    # An inline class to provide additional information on the form.
    class Meta:
        # Provide an association between the ModelForm and a model
        model = Rooms
