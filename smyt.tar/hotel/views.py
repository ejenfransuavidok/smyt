# -*- coding: utf-8 -*-
from django.shortcuts import render, render_to_response
from django.template.loader import render_to_string
from django.middleware.csrf import get_token
from django.http import HttpResponse
from models import Rooms, Users
from forms import UsersForm, RoomsForm
import json, sys
from datetime import datetime
from django.core import serializers

# Create your views here.

def users(request):
    return render_to_response('hotel/users.html', {'users': Users.objects.all(), 'form': UsersForm().as_p(), 'csrf_token_value': get_token(request)})

def adduser(request):
    result = {}
    form = UsersForm(request.POST)
    try:
        if form.is_valid():
            users = form.save(commit=True)
            result['id'] = users.id
            result['name'] = users.name
            result['paycheck'] = users.paycheck
            result['date_joined'] = users.date_joined.strftime("%m/%d/%Y")
            result['result'] = 'added'
        else:
            result['result'] = u'Ошибка!!! Проверьте введенные данные.'
        return HttpResponse( json.JSONEncoder().encode(result) )
    except:
        return HttpResponse( sys.exc_info()[0] )

def changeuser(request):
    result = {}
    try:
        u = Users.objects.get(id=request.POST['id'])
    except Users.DoesNotExist:
        result['result'] = False
        result['message'] = u'Объект не найден'
        return HttpResponse( json.JSONEncoder().encode(result) )
    result['name'] = request.POST['name']
    result['paycheck'] = request.POST['paycheck']
    result['date_joined'] = request.POST['date_joined']
    u.name = result['name']
    u.paycheck = result['paycheck']
    u.date_joined = datetime.strptime(request.POST['date_joined'], '%m/%d/%Y')
    try:
        u.save()
    except:
        result['result'] = False
        result['message'] = '%s' % sys.exc_info()[0]
        return HttpResponse( json.JSONEncoder().encode(result) )
    result['result'] = True
    result['message'] = u'Запись успешно изменена!!!'
    return HttpResponse( json.JSONEncoder().encode(result) )

def rooms(request):
    return render_to_response('hotel/rooms.html', {'rooms': Rooms.objects.all(), 'form': RoomsForm().as_p(), 'csrf_token_value': get_token(request)})

def addroom(request):
    result = {}
    form = RoomsForm(request.POST)
    try:
        if form.is_valid():
            rooms = form.save(commit=True)
            result['id'] = rooms.id
            result['department'] = rooms.department
            result['spots'] = rooms.spots
            result['result'] = 'OK'
        else:
            result['result'] = u'Ошибка!!! Проверьте введенные данные.'
        return HttpResponse( json.JSONEncoder().encode(result) )
    except:
        return HttpResponse( sys.exc_info()[0] )

def changeroom(request):
    result = {}
    try:
        r = Rooms.objects.get(id=request.POST['id'])
    except Rooms.DoesNotExist:
        result['result'] = False
        result['message'] = u'Объект не найден'
        return HttpResponse( json.JSONEncoder().encode(result) )
    result['department'] = request.POST['department']
    result['spots'] = request.POST['spots']
    r.department = result['department']
    r.spots = result['spots']
    try:
        r.save()
    except:
        result['result'] = False
        result['message'] = '%s' % sys.exc_info()[0]
        return HttpResponse( json.JSONEncoder().encode(result) )
    result['result'] = True
    result['message'] = u'Запись успешно изменена!!!'
    return HttpResponse( json.JSONEncoder().encode(result) )

def export(request):
    ucount = 0
    rcount = 0
    f = open('users.xml', 'r')
    data = f.read()
    for u in serializers.deserialize("xml", data):
        U = Users(name=u.object.name, paycheck=u.object.paycheck, date_joined=u.object.date_joined)
        U.save()
        ucount = ucount + 1
    f.close()
    f = open('rooms.xml', 'r')
    data = f.read()
    for r in serializers.deserialize("xml", data):
        R = Rooms(department=r.object.department, spots=r.object.spots)
        R.save()
        rcount = rcount + 1
    f.close()
    return HttpResponse( 'been exported %s Users(%s) records, %s Rooms(%s) records' % (ucount, Users.objects.all().count(), rcount, Rooms.objects.all().count()) )

def main(request):
    return render_to_response( 'hotel/main.html', {'data': render_to_string('hotel/users.html', {'users': Users.objects.all(), 'form': UsersForm().as_p(), 'csrf_token_value': get_token(request)})})
